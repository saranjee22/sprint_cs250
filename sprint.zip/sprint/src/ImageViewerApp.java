import javax.swing.*;

public class ImageViewerApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                ImageViewer viewer = new ImageViewer();
                viewer.setVisible(true);
            }
        });
    }
}
